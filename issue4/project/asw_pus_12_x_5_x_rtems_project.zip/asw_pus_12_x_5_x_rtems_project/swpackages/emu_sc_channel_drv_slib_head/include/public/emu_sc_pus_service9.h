/*
 * emu_sc_pus_service9.h
 *
 *  Created on: Jan 16, 2017
 *      Author: user
 */

#ifndef EMU_SC_PUS_SERVICE9_H_
#define EMU_SC_PUS_SERVICE9_H_

class Program9_129TC:public ProgramTC{

public:

  Program9_129TC(uint32_t uniTime2YK,
                 char * brief,uint32_t nextUniTime2YK);
};





#endif /* EMU_SC_PUS_SERVICE9_H_ */
