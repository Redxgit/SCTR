/*
 * emu_sc_pus_service17.h
 *
 *  Created on: Nov 12, 2018
 *      Author: user
 */

#ifndef EMU_SC_PUS_SERVICE17_H_
#define EMU_SC_PUS_SERVICE17_H_

class Program17_1TC:public ProgramTC{

public:

  Program17_1TC(uint32_t uniTime2YK,
                 char * brief);
};




#endif /* EMU_SC_PUS_SERVICE17_H_ */
