#include <public/icuasw_pus_services_iface_v1.h>

void CDSensorTMBufferStatus::GetCurrentStatus(){

    //Code for getting current status
    timestamp_Y2K=PUSService9::CurrentUniTimeY2KSecns;


  }
