#ifndef FCDTMMemoryH
#define FCDTMMemoryH
class CDTMMemory{
	
	public:
	
	protected:
	
	private:
	
};
#endif
