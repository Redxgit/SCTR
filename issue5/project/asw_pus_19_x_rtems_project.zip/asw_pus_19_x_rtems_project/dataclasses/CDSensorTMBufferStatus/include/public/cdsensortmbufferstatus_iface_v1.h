/*
 * cdsensorstmbufferstatus_iface_v1.h
 *
 *  Created on: Jan 9, 2017
 *      Author: user
 */

#ifndef CDSENSORSTMBUFFERSTATUS_IFACE_V1_H_
#define CDSENSORSTMBUFFERSTATUS_IFACE_V1_H_

#include <public/cdsensortmbufferstatus.h>


#endif /* CDSENSORSTMBUFFERSTATUS_IFACE_V1_H_ */
