/*
 * cdtcdescriptor_iface_v1.h
 *
 *  Created on: Dec 20, 2016
 *      Author: user
 */

#ifndef CDTCDESCRIPTOR_IFACE_V1_H_
#define CDTCDESCRIPTOR_IFACE_V1_H_

#include <public/cdtcdescriptor.h>

#endif /* CDTCDESCRIPTOR_IFACE_V1_H_ */
