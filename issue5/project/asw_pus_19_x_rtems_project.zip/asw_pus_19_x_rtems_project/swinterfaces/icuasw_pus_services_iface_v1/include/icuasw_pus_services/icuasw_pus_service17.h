/*
 * icuasw_pus_Service17.h
 *
 *  Created on: Dec 22, 2016
 *      Author: user
 */



#ifndef PUBLIC__ICUASW_PUS_SERVICE17_H
#define PUBLIC__ICUASW_PUS_SERVICE17_H

class PUSService17:public PUSServices{

public:
  static void ExecTC( CDTCDescriptor &TC, CDTMList &List);

};
#endif
